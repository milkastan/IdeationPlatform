package pages;

public class Discussions extends Base{

}
